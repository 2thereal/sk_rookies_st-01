export const normalizeForSearch = (text) =>
  text
    .toLowerCase()
    .replace(/["'`“”‘’\[\]{}()<>]/g, ' ')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();

export const stripKoreanParticles = (token) => {
  if (!token) {
    return token;
  }

  let result = token
    .replace(/돼/gu, '되')
    .replace(/됐/gu, '되었')
    .replace(/(입니다|입니까|합니다|합니까|했나요|했습니까)$/gu, '')
    .replace(
      /(은|는|이|가|을|를|에|에서|으로|로|와|과|도|만|뿐|부터|까지|에게|께|한테|이나|나|라고|이라고|이라|라서|랑|이랑|하고|하며|이고|거나|지만|라도|라도요|라도요|네요|나요|죠|요|다|까)$/gu,
      ''
    );

  if (result.length >= 2) {
    return result;
  }

  return token;
};

export const tokenize = (text) =>
  [
    ...new Set(
      normalizeForSearch(text)
        .split(' ')
        .map(stripKoreanParticles)
        .filter((token) => token.length >= 2)
    ),
  ];

export const collapseWhitespace = (text) => text.replace(/\s+/g, '');
