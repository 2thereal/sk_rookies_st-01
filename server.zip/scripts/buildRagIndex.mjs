#!/usr/bin/env node
import { mkdir, readFile, writeFile } from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  normalizeForSearch,
  tokenize,
  collapseWhitespace,
} from '../utils/textProcessing.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const serverRoot = path.resolve(__dirname, '..');
const guidePath = path.resolve(serverRoot, 'guide.txt');
const outputDir = path.resolve(serverRoot, 'data');
const outputPath = path.resolve(outputDir, 'guide_index.json');

const DEFAULT_CHUNK_LINES = 8;
const DEFAULT_OVERLAP_LINES = 2;
const DEFAULT_MIN_CHARS = 120;

const chunkSize = Number.parseInt(process.env.RAG_CHUNK_LINES ?? process.argv[2] ?? `${DEFAULT_CHUNK_LINES}`, 10);
const rawOverlap = Number.parseInt(process.env.RAG_CHUNK_OVERLAP ?? process.argv[3] ?? `${DEFAULT_OVERLAP_LINES}`, 10);
const minChars = Number.parseInt(process.env.RAG_MIN_CHARS ?? process.argv[4] ?? `${DEFAULT_MIN_CHARS}`, 10);
const chunkOverlap = Math.max(0, Math.min(rawOverlap, Math.max(0, chunkSize - 1)));

async function buildIndex() {
  const guideRaw = await readFile(guidePath, 'utf-8');
  const lines = guideRaw.split(/\r?\n/);

  const chunks = [];
  let start = 0;
  let chunkCounter = 0;

  while (start < lines.length) {
    const end = Math.min(lines.length, start + chunkSize);
    const chunkLines = lines.slice(start, end);
    const text = chunkLines.join('\n').trim();

    if (text) {
      const normalized = normalizeForSearch(text);
      const collapsed = collapseWhitespace(normalized);
      const tokens = tokenize(text);
      chunkCounter += 1;
      chunks.push({
        id: `chunk-${String(chunkCounter).padStart(4, '0')}`,
        start_line: start + 1,
        end_line: end,
        text,
        normalized,
        collapsed,
        tokens,
      });
    }

    if (end >= lines.length) {
      break;
    }

    const nextStart = end - chunkOverlap;
    start = nextStart > start ? nextStart : end;
  }

  const filteredChunks = chunks.filter((chunk) => chunk.text.length >= minChars || chunks.length === 1);

  await mkdir(outputDir, { recursive: true });
  await writeFile(
    outputPath,
    JSON.stringify(
      {
        source_file: path.relative(serverRoot, guidePath),
        generated_at: new Date().toISOString(),
        chunk_size_lines: chunkSize,
        chunk_overlap_lines: chunkOverlap,
        min_chars: minChars,
        chunk_count: filteredChunks.length,
        chunks: filteredChunks,
      },
      null,
      2,
    ),
    'utf-8',
  );

  console.log(`✅ Generated ${filteredChunks.length} chunks -> ${path.relative(process.cwd(), outputPath)}`);
}

buildIndex().catch((error) => {
  console.error('❌ Failed to build RAG index:', error);
  process.exit(1);
});
